#ifndef INVADER_H
#define INVADER_H
#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Enemy.h"

using namespace sf;

class invader:public Enemy
{
 public:
 float delay;
 	invader()
 	{
 		delay=0;
		//setScale(0.5,0.5);
	}
};



#endif
