#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <time.h>
#include <cmath>
#include <cstdlib>
#include <string.h>
#include <string>
#include <iostream>
#include "player.h"
#include "Enemy.h"
#include "bullet.h"
#include "bomb.h"
#include "invader.h"
#include "Alpha.h"
#include "Beta.h"
#include "Gamma.h"
#include "Monster.h"
#include "Addon.h"
#include "Lives.h"
#include "Danger.h"
#include "Fireball.h"
#include "Fire.h"
#include "Dragon.h"
#include "Bronze.h"
#include "Silver.h"
#include "Gold.h"
#include "menu.h"
#include "RapidFire.h"
#include <fstream>
#include <sstream>

const char title[] = "OOP-Project, Spring-2023";
using namespace sf;
using namespace std;

void sortRecords();
// Structure to hold player records
struct PlayerRecord {
    std::string playerName;
    int score;
};
void checkAndReplaceRecord(const std::string& playerName, int score);
void sortRecords();
string getTop10Records();

class Game
{ 
public:

Sprite background,pause; //Game background sprite
Texture tex1,tex2,tex3,tex4,tex5,tex6,tex7,tex8,tex9,tex10;
Sprite  health,gameover,f,level1,end,kaboom;
Texture bg_texture,tex;
Player* p; //player 
Player* p1;
Player* p2;
Player* p3;
Player* p4;
Player* p5;
Player* p6;
// add other game attributes
Alpha Ax;
Beta* e2;
Gamma* e3;
//Enemy* e1;
Alpha* e1; // Array of Enemy pointers
Monster M;
Dragon Dr;
Enemy* e4;
Enemy* e5;
Enemy* e6;


Lives L;
Danger D;
Fire F;
Bronze B;
Silver S;
Gold G;
Rapid R;
Addon* A;
Addon* A1; 
Addon* A2;
Addon* A3;
Addon* A4;
Addon* A5;
Addon* A6;
Menu m;
string top10Records;
//Enemy* e2=&B;
//Enemy* e3=&G;
bool x,y,z,n;
bool fire=false;
bool gamestart=true;
char s;

Game()
{
A=nullptr;
A1=nullptr;
A2=nullptr;
A3=nullptr;
A4=nullptr;
A5=nullptr;
A6=nullptr;
e4=nullptr;
e5=nullptr;
e6=nullptr;
p=new Player("img/player_ship.png");
p1=new Player();
p2=new Player();
p3=new Player();
p4=new Player();
p5=new Player();
p6=new Player();
bg_texture.loadFromFile("img/background_1.png");
tex2.loadFromFile("img/gameover.jpg");
tex3.loadFromFile("img/images.jpg");
tex4.loadFromFile("img/fire.png");
tex5.loadFromFile("img/level1.png");
tex6.loadFromFile("img/level2.png");
tex7.loadFromFile("img/level3.png");
tex8.loadFromFile("img/End.png");
tex9.loadFromFile("img/kaboom.png");
tex10.loadFromFile("img/Health.jpg");
kaboom.setTexture(tex9);
end.setTexture(tex8);
end.setScale(1,1.4);
f.setTexture(tex4);
f.setPosition(1000,1000);
f.setScale(1,4);
health.setTexture(tex3);
health.setPosition(300,300);
level1.setTexture(tex5);
background.setTexture(bg_texture);
background.setScale(2, 1.5);
level1.setPosition(200,200);
level1.setScale(1.5,1.5);

    m.scores=getTop10Records();

}

void start_game()
{
   
    m.display_menu();
      A = &L;
      A1= &D;
      A2=&F;
      A3=&B;
      A4=&S;
      A5=&G;
      A6=&R;
      e4=&M;
      e5=&Ax;
      e6=&Dr;
       FloatRect playerBounds = p->sprite.getGlobalBounds();
    srand(time(0));
    RenderWindow window(VideoMode(780, 780), title);
    Clock clock;
    sf::Font font;
    sf::Font font2;
    if (!font2.loadFromFile("img/Roboto-Black.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
       
    }
    font.loadFromFile("img/Roboto-Black.ttf");
    sf::Text text;
    sf::Text text2;
     text2.setFont(font2);
    text2.setCharacterSize(20);
    text2.setFillColor(sf::Color::Black);
    text2.setPosition(20.f, 20.f);
    sf::Music music;
   	if(!music.openFromFile("img/BattleintheStars.ogg"))
   {}
   music.setLoop(true);
   music.play(); 
    text.setFont(font);
    sf::SoundBuffer buffer1;
    sf::SoundBuffer buffer2;
     sf::SoundBuffer buffer3;
     sf::SoundBuffer buffer4;
     sf::SoundBuffer buffer5;
     sf::SoundBuffer buffer6;
     sf::SoundBuffer buffer7;
     sf::SoundBuffer buffer8;
     
     
	 if (!buffer1.loadFromFile("img/laser.wav") || !buffer7.loadFromFile("img/end.wav") || !buffer8.loadFromFile("img/coin.wav") || !buffer2.loadFromFile("img/falling hit.wav") || !buffer6.loadFromFile("img/Powerupsound.wav") || !buffer3.loadFromFile("img/PUNCH.wav") || !buffer4.loadFromFile("img/salam.wav") || !buffer5.loadFromFile("img/powerup.wav"))
    {}
	sf::Sound sound1(buffer1);
    sf::Sound sound2(buffer2);
    sf::Sound sound3(buffer3);
    sf::Sound sound4(buffer4);
    sf::Sound sound5(buffer5);
    sf::Sound sound6(buffer6);
    sf::Sound sound7(buffer7);
    sf::Sound sound8(buffer8);
    
    float timer=0;
    float timerx=0;
    float timer2[5]={0};

    float timer3[6]={0};
    float timer4[4]={0};
    float timer5=0;
    float timery=0;
    float timer6=0;
    float timer8=0;
    float timer9=0;
    float timer10=5;
    float timer11=0;
    float timer13=3;
    float timer14=0;
    float timer15=0;
    float timer16=0;
    float timer17=0;
    float timer18=0;
    float timer19=0;
    float time_shoot = 0;
    float time_shoot2=0;
    float time_wave=0;
    float time_level=0;
    float time_monster=0;
    float time_dragon=0;
    float timer_death=0;
    bool shoot_halt = false;
    bool shoot_halt2 =false;
    bool collision=false;
    bool check=false;
    bool check2=false;
    bool cooldown=false;
    int level=1;
    int wave=1;
    bool monster=false;
    bool dragon=false;
    bool ended=false;
      int numAlpha=1; 
      int numBeta=1;
      int numGamma=1;
      int count=1; 
      int lives=3; 
      int score=0;
      string name;
      
      string scoreboardText;
     //  showscoreboard(scoreboardText, score);

    // Set the scoreboard text
    
      bool collisionDetected = false;
      bool collisionDetected2 = false;
      
        sf::Clock timer7;
        sf:: Clock timer12;
        sf::Time collisionDelay = sf::seconds(2.0f);  // Adjus
        sf::Time collisionDelay2 = sf::seconds(4.0f);  // Adjus
      e5=new Alpha[numAlpha];   
      Sprite* heart;
        
     
     
    while (window.isOpen())
    {
       // if(lives==0)
      //      window.close();
      
    heart=new Sprite[lives + 1];
          for(int i=0;i<lives;i++)
    {
        heart[i].setTexture(tex10);
        heart[i].setPosition(i * 30,0);
        heart[i].setScale(0.01,0.01);
    }
       string str1 = to_string(score);
     
       sf::Time elapsed = timer7.getElapsedTime();
         if (elapsed >= collisionDelay) {
        collisionDetected = false;
        timer7.restart();
            }
             sf::Time elapsed2 = timer12.getElapsedTime();
         if (elapsed2 >= collisionDelay2) {
        collisionDetected2 = false;
        timer12.restart();
            }
      
        p->add=A;
       p1->add=A1;
       p2->add=A2;
       p3->add=A3;
       p4->add=A4;
       p5->add=A5;
       p6->add=A6;

        if(count==1 && numAlpha==0 && numBeta==0 && numGamma==0)
        {
            level1.setTexture(tex5);
            count=2;
            level=1;
            wave=2;
            timerx=0;
            time_wave=0;
        }
        else if(count==2 && numAlpha==0 && numBeta==0 && numGamma==0)
        {
            count=3;
            level=1;
            wave=3;
            timerx=0;
            time_wave=0;
        }
       else if(count==3 && numAlpha==0 && numBeta==0 && numGamma==0 )
        {
            level1.setTexture(tex6);
            count=4;
            level=2;
            wave=4;
            timerx=0;
            time_level=0;
        }
        else if(count==4 && numAlpha==0 && numBeta==0 && numGamma==0)
        {
            count=5;
            level=2;
            wave=5;
            timerx=0;
        }
        else if(count==5 && numAlpha==0 && numBeta==0 && numGamma==0 )
        {
            count=6;
            level=2;
            wave=6;
            timerx=0;
        }
        else if(count==6 && numAlpha==0 && numBeta==0 && numGamma==0 )
        {
            level1.setTexture(tex7);
            count=7;
            level=3;
            wave=7;
            timerx=0;
            time_level=0;
        }
         else if(count==7 && numAlpha==0 && numBeta==0 && numGamma==0 )
        {
            count=8;
            level=3;
            wave=8;
            timerx=0;
        }
        else if(count==8 && numAlpha==0 && numBeta==0 && numGamma==0 )
        {
            count=9;
            level=3;
            wave=9;
            timerx=0;
        }
        else if(count==9 && numAlpha==0 && numBeta==0 && numGamma==0 )
        {
            count=10;
            level=3;
            wave=10;
            timerx=0;
        }
        else if(count==10 && numAlpha==0 && numBeta==0 && numGamma==0 )
        {
            count=11;
            level=3;
            wave=11;
            timerx=0;
        }
        else if(count==11 && numAlpha==0 && numBeta==0 && numGamma==0 )
        {
            gamestart=false;
           ended=true;
            count=1;
           level=1;
            wave=1;
     /*  float timer=0;
     timerx=0;
    timer2[5]={0};

     timer3[6]={0};
    timer4[4]={0};
    timer5=0;
    timery=0;
    timer6=0;
    timer8=0;
    timer9=0;
    timer10=5;
     timer11=0;
     timer13=3;
     timer14=0;
     timer15=0;
     timer16=0;
     timer17=0;
     timer18=0;
     timer19=0;
     time_shoot = 0;
     time_shoot2=0;
     time_wave=0;
     time_level=0;
     time_monster=0;
     time_dragon=0;
     timer_death=0;*/
            music.stop();
            sound7.play();
            window.draw(end);
            text.setString("Your Score:");
            text.setCharacterSize(36);
             text.setFillColor(sf::Color::White);
             text.setStyle(sf::Text::Bold | sf::Text::Underlined);
             text.setPosition(sf::Vector2f(300,100));
             window.draw(text);
        
             text.setString(str1);
            text.setCharacterSize(33);
             text.setFillColor(sf::Color::Cyan);
            text.setPosition(sf::Vector2f(300,150));
            window.draw(text);
            if(ended){
            cout<<"Enter your name: ";
            cin>>name;
            checkAndReplaceRecord(name, score);
            // sortRecords();
            top10Records = getTop10Records();
            m.scores=top10Records;
            }
            ended=false;
            window.display();
            


        }
    	if(count==1 && level==1 && wave==1){
            numAlpha=4;
            numBeta=4;
            numGamma=4;
           sound4.play(); 
           p->sprite.setPosition(340,700);
         e1 = new Alpha[numAlpha]{
        Alpha(325, 200),  // Set position for enemy 1
        Alpha(210, 200),  // Set position for enemy 2
        Alpha(450, 200),  // Set position for enemy 4
        Alpha(325, 400)   // Set position for enemy 5
        };
        e2=new Beta[numBeta]{
        Beta(100, 300),  // Set position for enemy 1
        Beta(575, 300),   // Set position for enemy 5
        Beta(210, 400),  // Set position for enemy 2
        Beta(450, 400),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(100, 200),  // Set position for enemy 1
        Gamma(575, 200),  // Set position for enemy 2
        Gamma(100, 400),  // Set position for enemy 3
        Gamma(575, 400),  // Set position for enemy 4
            };
       
        }
        if(count==2 && level==1 && wave==2)
        {
            for(int i=0;i< 15;i++);
            numAlpha=3;
            numBeta=2;
            numGamma=5;
            p->sprite.setPosition(340,700);
            sound4.play();
            e1 = new Alpha[numAlpha]{
       
        Alpha(315, 400),   // Set position for enemy 5
        Alpha(510,400),
        Alpha(80,400)
        };
        e2=new Beta[numBeta]{
        Beta(410,400),
        Beta(170,400)
        };
        e3 = new Gamma[numGamma]{
        Gamma(300, 100),  // Set position for enemy 1
        Gamma(200, 200),  // Set position for enemy 2
        Gamma(100, 300),  // Set position for enemy 3
        Gamma(400, 200),  // Set position for enemy 4
        Gamma(500,300)
            };
        }
        if(count==3 && level==1 && wave==3)
        {
            numAlpha=6;
            numBeta=6;
            numGamma=3;
            sound4.play();
            p->sprite.setPosition(340,700);
            e1 = new Alpha[numAlpha]{
       
        Alpha(50, 50),   // Set position for enemy 5
        Alpha(120,120),
        Alpha(200,200),
        Alpha(400,400),
        Alpha(500,500),
        Alpha(600,600)
        };
        e2=new Beta[numBeta]{
        Beta(600, 50),  // Set position for enemy 1
        Beta(500, 120),  // Set position for enemy 2
        Beta(400, 200),  // Set position for enemy 4
        Beta(200, 400),   // Set position for enemy 5
        Beta(120,500),
        Beta(50,600),
        };
        e3 = new Gamma[numGamma]{
        Gamma(300, 300),  // Set position for enemy 1
        Gamma(200, 300),  // Set position for enemy 2
        Gamma(400, 300),  // Set position for enemy 3
         };
        }

         
    	if(count==4 && level==2 && wave==4){
            level=2;
            numAlpha=4;
            numBeta=4;
            numGamma=2;
        sound4.play();
        p->sprite.setPosition(340,700);
         e1 = new Alpha[numAlpha]{
        Alpha(150, 200),  // Set position for enemy 1
        Alpha(250, 100),  // Set position for enemy 2
        Alpha(400, 100),  // Set position for enemy 4
        Alpha(500, 200)   // Set position for enemy 5
        };
        e2=new Beta[numBeta]{
        Beta(150, 400),  // Set position for enemy 1
        Beta(250, 500),   // Set position for enemy 5
        Beta(400,500),
        Beta(500, 400),  // Set position for enemy 2
       // Beta(450, 400),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(550, 300),  // Set position for enemy 1
        Gamma(100, 300),  // Set position for enemy 2
            };
        }

        if(count==5 && level==2 && wave==5){
            level=2;
            numAlpha=4;
            numBeta=5;
            numGamma=3;
            p->sprite.setPosition(340,700);
        sound4.play();
         e1 = new Alpha[numAlpha]{
        Alpha(100, 100),  // Set position for enemy 1
        Alpha(200, 200),  // Set position for enemy 2
        Alpha(450, 200),  // Set position for enemy 4
        Alpha(550, 100)   // Set position for enemy 5
        };
        e2=new Beta[numBeta]{
        Beta(100, 300),  // Set position for enemy 1
        Beta(200, 400),   // Set position for enemy 5
        Beta(450, 400),
        Beta(550, 300),  // Set position for enemy 2
        Beta(320, 500),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(600, 200),  // Set position for enemy 1
        Gamma(50, 200),  // Set position for enemy 2
        Gamma(330,250)
            };
        }
        if(count==6 && level==2 && wave==6)
        {
            numAlpha=2;
            numBeta=4;
            numGamma=5;
            sound4.play();
            p->sprite.setPosition(340,700);
            e1 = new Alpha[numAlpha]{
       
       // Alpha(315, 400),   // Set position for enemy 5
        Alpha(530,400),
        Alpha(50,400)
        };
        e2=new Beta[numBeta]{
        Beta(100, 500),  // Set position for enemy 1
        Beta(215, 600),   // Set position for enemy 5
        Beta(400, 600),
        Beta(500, 500),  // Set position for enemy 2
       // Beta(320, 600),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(300, 100),  // Set position for enemy 1
        Gamma(200, 200),  // Set position for enemy 2
        Gamma(100, 300),  // Set position for enemy 3
        Gamma(400, 200),  // Set position for enemy 4
        Gamma(500,300)
            };
        }
        
        if(count==7 && level==3 && wave==7){
            numAlpha=5;
            numBeta=6;
            numGamma=4;
        sound4.play();
        p->sprite.setPosition(340,700);
         e1 = new Alpha[numAlpha]{
        Alpha(325, 200),  // Set position for enemy 1
        Alpha(210, 200),  // Set position for enemy 2
        Alpha(325, 300),  // Set position for enemy 3
        Alpha(450, 200),  // Set position for enemy 4
        Alpha(325, 400)   // Set position for enemy 5
        };
        e2=new Beta[numBeta]{
        Beta(100, 300),  // Set position for enemy 1
        Beta(210, 300),  // Set position for enemy 2
        Beta(450, 300),  // Set position for enemy 4
        Beta(575, 300),   // Set position for enemy 5
        Beta(210, 400),  // Set position for enemy 2
        Beta(450, 400),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(100, 200),  // Set position for enemy 1
        Gamma(575, 200),  // Set position for enemy 2
        Gamma(100, 400),  // Set position for enemy 3
        Gamma(575, 400),  // Set position for enemy 4
            };
       
        }
        if(count==8 && level==3 && wave==8)
        {
            numAlpha=3;
            numBeta=9;
            numGamma=5;
            sound4.play();
            p->sprite.setPosition(340,700);
            e1 = new Alpha[numAlpha]{
       
        Alpha(315, 400),   // Set position for enemy 5
        Alpha(510,400),
        Alpha(80,400)
        };
        e2=new Beta[numBeta]{
        Beta(300, 200),  // Set position for enemy 1
        Beta(300, 300),  // Set position for enemy 2
        Beta(400, 300),  // Set position for enemy 4
        Beta(200, 300),   // Set position for enemy 5
        Beta(410,400),
        Beta(170,400),
        Beta(100,300),
        Beta(200, 400),  // Set position for enemy 2
        Beta(450, 400),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(300, 100),  // Set position for enemy 1
        Gamma(200, 200),  // Set position for enemy 2
        Gamma(100, 300),  // Set position for enemy 3
        Gamma(400, 200),  // Set position for enemy 4
        Gamma(500,300)
            };
        }
        if(count==9 && level==3 && wave==9){
            level=3;
            numAlpha=7;
            numBeta=7;
            numGamma=5;
        sound4.play();
        p->sprite.setPosition(340,700);
         e1 = new Alpha[numAlpha]{
        Alpha(150, 200),  // Set position for enemy 1
        Alpha(250, 100),  // Set position for enemy 2
        Alpha(400, 100),  // Set position for enemy 4
        Alpha(500, 200),   // Set position for enemy 5
        Alpha(225,200),
        Alpha(325,200),
        Alpha(425,200)
        };
        e2=new Beta[numBeta]{
        Beta(120, 400),  // Set position for enemy 1
        Beta(250, 500),   // Set position for enemy 5
        Beta(400,500),
        Beta(525, 400),  // Set position for enemy 2
        Beta(225,400),
        Beta(325,400),
        Beta(425,400)
       // Beta(450, 400),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(550, 300),  // Set position for enemy 1
        Gamma(100, 300),  // Set position for enemy 2
        Gamma(325,300),
        Gamma(225,300),
        Gamma(425,300)
            };
        }
        if(count==10 && level==3 && wave==10){
            level=3;
            numAlpha=4;
            numBeta=10;
            numGamma=4;
            p->sprite.setPosition(340,700);
        sound4.play();
         e1 = new Alpha[numAlpha]{
        Alpha(100, 100),  // Set position for enemy 1
        Alpha(200, 200),  // Set position for enemy 2
        Alpha(450, 200),  // Set position for enemy 4
        Alpha(550, 100)   // Set position for enemy 5
        };
        e2=new Beta[numBeta]{
        Beta(100, 300),  // Set position for enemy 1
        Beta(200,300),
        Beta(325,330),
        Beta(450,300),
        Beta(200, 400),   // Set position for enemy 5
        Beta(450, 400),
        Beta(550, 300),  // Set position for enemy 2
        Beta(125,200),
        Beta(525,200),
        Beta(320, 500),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(600, 200),  // Set position for enemy 1
        Gamma(50, 200),  // Set position for enemy 2
        Gamma(330,250),
        Gamma(330,420)
            };
        }
        if(count==11 && level==3 && wave==11)
        {
            level=3;
            numAlpha=6;
            numBeta=7;
            numGamma=9;
            sound4.play();
            p->sprite.setPosition(340,700);
            e1 = new Alpha[numAlpha]{
       
       // Alpha(315, 400),   // Set position for enemy 5
        Alpha(530,400),
        Alpha(50,400),
        Alpha(150,400),
        Alpha(250,400),
        Alpha(350,400),
        Alpha(450,400)
        };
        e2=new Beta[numBeta]{
        Beta(100, 500),  // Set position for enemy 1
        Beta(215, 600),   // Set position for enemy 5
        Beta(400, 600),
        Beta(500, 500),  // Set position for enemy 2
        Beta(200,500),
        Beta(300,500),
        Beta(400,500)
       // Beta(320, 600),  // Set position for enemy 4
        };
        e3 = new Gamma[numGamma]{
        Gamma(300, 100),  // Set position for enemy 1
        Gamma(200,300),
        Gamma(300,200),
        Gamma(300,300),
        Gamma(400,300),
        Gamma(200, 200),  // Set position for enemy 2
        Gamma(100, 300),  // Set position for enemy 3
        Gamma(400, 200),  // Set position for enemy 4
        Gamma(500,300)
            };
        }
        
        if(count==1)
        {            
            level=1;
        }
        
        if(count==2)
        {            
            level=1;
        }

        if(count==3)
        {            
            level=1;
        }

        if(count==4)
        {            
            level=2;
        }

        if(count==5)
        {            
            level=2;
        }

        if(count==6)
        {            
            level=2;
        }
        if(count==7)
        {            
            level=3;
        }
        if(count==8)
        {            
            level=3;
        }
        if(count==9)
        {            
            level=3;
        }
        if(count==10)
        {            
            level=3;
        }
        if(count==11)
        {            
            level=3;
        }
        float time = clock.getElapsedTime().asSeconds(); 
        clock.restart();
        timer += time;  
        for(int i=0;i<5;i++)
            timer2[i] += time;
        for(int i=0;i<6;i++) 
            timer3[i] += time;
        for(int i=0;i<4;i++) 
            timer4[i] += time;
        //timer5 += time;
        timerx += time;
        timer6 += time;
        timer8 +=time;
        timer9 += time;
        timer10 += time;
        timer13 += time;
        timer16 += time;
        timer17 +=time;
        timer18 += time;
        timer19 += time;
        timery += time;
        timer_death += time;
        time_monster += time;
        time_dragon += time;
        time_level += time;
 	Event e;
        while (window.pollEvent(e))
        {  
            if (e.type == Event::Closed) // If cross/close is clicked/pressed
                window.close(); //close the game                        	    
        }
        
        
       	if (Keyboard::isKeyPressed(Keyboard::H)){
          	gamestart=false;
          	tex.loadFromFile("img/pause.png");
          	pause.setTexture(tex);
            pause.setScale(1.1,1.2);
          	window.draw(pause);
          	window.display();
          		
          }
        if(gamestart==false && Keyboard::isKeyPressed(Keyboard::Num9)){
                        music.stop();
                        window.close();
                        Game G;
                        G.start_game();    
                        return;
					}
        if (gamestart==false && Keyboard::isKeyPressed(Keyboard::Num4))
          		exit(0);  
       
       else if (lives!=0 && Keyboard::isKeyPressed(Keyboard::Num1))
        	gamestart=true;
        
        if(gamestart){ 	
          
	if (Keyboard::isKeyPressed(Keyboard::Left)){ //If left key is pressed
            p->move("l");    // Player will move to left
            z=true;
            s='l';
         }
	if (Keyboard::isKeyPressed(Keyboard::Right)){ // If right key is pressed
            p->move("r");  //player will move to right
            x=true;
            s='l';
        }
	if (Keyboard::isKeyPressed(Keyboard::Up)){ //If up key is pressed
            p->move("u");    //playet will move upwards
            y=true;
            s='l';
          }
	if (Keyboard::isKeyPressed(Keyboard::Down)){ // If down key is pressed
            p->move("d");  //player will move downwards
            n=true;
            s='l';
          }
        if (Keyboard::isKeyPressed(Keyboard::Right) && Keyboard::isKeyPressed(Keyboard::Up)){
                 //     p->rotateSprite(p->sprite,45.f);
                      
                    p->move("x");
                    s='x';
                    
          }
        else if (Keyboard::isKeyPressed(Keyboard::Left) && Keyboard::isKeyPressed(Keyboard::Up)){
                 //     p->rotateSprite(p->sprite,45.f);
                      
                    p->move("y");
                    s='y';
          }
       	else if (Keyboard::isKeyPressed(Keyboard::Right) && Keyboard::isKeyPressed(Keyboard::Down)){
                 //     p->rotateSprite(p->sprite,45.f);
                      
                    p->move("z");
                    s='z';
          }
        else if (Keyboard::isKeyPressed(Keyboard::Left) && Keyboard::isKeyPressed(Keyboard::Down)){
                 //     p->rotateSprite(p->sprite,45.f);
                      
                    p->move("n");
                    s='n';
          }    
	////////////////////////////////////////////////
    window.clear(Color::Black); //clears the screen
	window.draw(background);  // setting background
     if(timer13>5)
        cooldown=false;

      if(timer>10){
    if(timer6>=p->add->getDelay()){
            p->useAddon();
            timer6=0;
    }
    else
    {
        p->add->move();
    }
      } 
      if(timer>6){
        if(timer8>=p1->add->getDelay())
                 {
                     p1->useAddon();
                    timer8=0;
                 }
            else
                {
        p1->add->move();
                 }
      }
      if(timer>5){
        if(timer19>=p6->add->getDelay())
                 {
                     p6->useAddon();
                    timer19=0;
                 }
            else
                {
        p6->add->move();
                 }
      }
      if(timer>25){
        if(timer16>=p3->add->getDelay())
                 {
                     p3->useAddon();
                    timer16=0;
                 }
            else
                {
        p3->add->move();
                 }
      }
      if(timer>50){
        if(timer17>=p4->add->getDelay())
                 {
                     p4->useAddon();
                    timer17=0;
                 }
            else
                {
        p4->add->move();
                 }
      }
      if(timer>100){
        if(timer18>=p5->add->getDelay())
                 {
                     p5->useAddon();
                    timer18=0;
                 }
            else
                {
        p5->add->move();
                 }
      }
      if(timer>0){
        if(timer9>=p2->add->getDelay() && !p->rapidfire)
                 {
                     p2->useAddon();
                    timer9=0;
                 }
            else
                {
        p2->add->move();
                 }
      }
      if(timer19>5)
        p->rapidfire=false;
    FloatRect livesBounds=p->add->getSprite().getGlobalBounds();
    FloatRect bronzeBounds=p3->add->getSprite().getGlobalBounds();
    FloatRect goldBounds=p5->add->getSprite().getGlobalBounds();
    FloatRect silverBounds=p4->add->getSprite().getGlobalBounds();
    FloatRect rapidBounds=p6->add->getSprite().getGlobalBounds();
    FloatRect playerBounds = p->sprite.getGlobalBounds();
    if (playerBounds.left < livesBounds.left + livesBounds.width &&
    playerBounds.left + playerBounds.width > livesBounds.left &&
    playerBounds.top < livesBounds.top + livesBounds.height &&
    playerBounds.top + playerBounds.height > livesBounds.top) {
        lives++;
        sound5.play();
      //  collisionDetected=true;
        timer6=0;
        p->add->getSprite().setPosition(1000, 1000);
    }
    if ( playerBounds.left < bronzeBounds.left + bronzeBounds.width &&
    playerBounds.left + playerBounds.width > bronzeBounds.left &&
    playerBounds.top < bronzeBounds.top + bronzeBounds.height &&
    playerBounds.top + playerBounds.height > bronzeBounds.top) {
        score +=50;
        sound8.play();
        timer16=0;
        p3->add->getSprite().setPosition(1000, 1000);
    }
    if ( playerBounds.left < silverBounds.left + silverBounds.width &&
    playerBounds.left + playerBounds.width > silverBounds.left &&
    playerBounds.top < silverBounds.top + silverBounds.height &&
    playerBounds.top + playerBounds.height > silverBounds.top) {
        score +=150;
        sound8.play();
        timer17=0;
        p4->add->getSprite().setPosition(1000, 1000);
    }
    if ( playerBounds.left < goldBounds.left + goldBounds.width &&
    playerBounds.left + playerBounds.width > goldBounds.left &&
    playerBounds.top < goldBounds.top + goldBounds.height &&
    playerBounds.top + playerBounds.height > goldBounds.top) {
        score +=500;
        sound8.play();
        timer18=0;
        p5->add->getSprite().setPosition(1000, 1000);
    }
        if(!monster && !dragon){

            if ( playerBounds.left < rapidBounds.left + rapidBounds.width &&
                playerBounds.left + playerBounds.width > rapidBounds.left &&
                playerBounds.top < rapidBounds.top + rapidBounds.height &&
                playerBounds.top + playerBounds.height > rapidBounds.top) 
                {
                p->rapidfire=true;
                sound8.play();
                timer19=0;
                p6->add->getSprite().setPosition(1000, 1000);
                }
        
	    if ( timer - time_shoot >= 0.5 )
	    {shoot_halt = false;}
	    
	   if (!p->rapidfire && !shoot_halt && timer10>5 && Keyboard::isKeyPressed(Keyboard::Q) && time_level>2)
        {
            p->fire(s);
            sound1.play();
            time_shoot = timer;
            shoot_halt = true;
        }
	    

        else if(p->rapidfire && !shoot_halt && time_level>2)
        {
            p->rapid_fire();
            sound1.play();
            time_shoot=timer;
            shoot_halt=true;
            cooldown=true;
            timer13=0;
        }
        p->update_bullet();
        

        if(timerx>5){
        for (int i = 0; i < numAlpha; i++) {
                if (timer2[i] >= e1[i].delay) {
                    e1[i].fire();
                    timer2[i] = -5;
                }
                else {
                    e1[i].b->bomb_move();
                }

              } 
            }

    for (int i = 0; i < numBeta; i++) {
        if(timerx>3){
                if (timer3[i] >= e2[i].delay) {
                    e2[i].fire();
                    timer3[i] = -3;
                }
                else {
                    e2[i].b->bomb_move();
                }

              }
            }
    for (int i = 0; i < numGamma; i++) {
            if(timerx>2){
                if (timer4[i] >= e3[i].delay) {
                    e3[i].fire();
                    timer4[i] = -3;
                }
                else {
                    e3[i].b->bomb_move();
                }

              }
            }
      
    FloatRect playerBounds = p->sprite.getGlobalBounds();
    FloatRect bombBounds[10]; 
    FloatRect bombBounds2[10];
    FloatRect bombBounds3[10];
    
    

    for (int i=0;i<numAlpha;i++)
    {
        bombBounds[i] = e1[i].b->bombs.getGlobalBounds();
    }
    for (int i=0;i<numBeta;i++)
    {
        bombBounds2[i] = e2[i].b->bombs.getGlobalBounds();
    }
    for (int i=0;i<numGamma;i++)
    {
        bombBounds3[i] = e3[i].b->bombs.getGlobalBounds();
    }
    FloatRect bulletBounds[p->numBullets];
    for (int i=0;i<p->numBullets;i++)
    {
        bulletBounds[i] = p->b[i].bullets.getGlobalBounds();
    }
    FloatRect e1Bounds[numAlpha];
    for (int i=0;i<numAlpha;i++)
    {
        e1Bounds[i] = e1[i].s1.getGlobalBounds();
    }
    FloatRect e2Bounds[numBeta];
    for (int i=0;i<numBeta;i++)
    {
        e2Bounds[i] = e2[i].s1.getGlobalBounds();
    }
    FloatRect e3Bounds[numGamma];
    for (int i=0;i<numGamma;i++)
    {
        e3Bounds[i] = e3[i].s1.getGlobalBounds();
    }
    
for (int i=0;i<10;i++){
    if (playerBounds.left < bombBounds[i].left + bombBounds[i].width &&
    playerBounds.left + playerBounds.width > bombBounds[i].left &&
    playerBounds.top < bombBounds[i].top + bombBounds[i].height &&
    playerBounds.top + playerBounds.height > bombBounds[i].top) {
    // Collision detected
    // Handle collision logic here
    if(!cooldown){
    lives-=1;
    cooldown=true;
    timer13=0;
    timery=0;
   
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<0.5){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
     
   
        e1[i].b->bombs.setPosition(1000,1000);
        p->sprite.setPosition(340,700);
    
        }
    } 



}
for (int i=0;i<numAlpha;i++){
    if (playerBounds.left < e1Bounds[i].left + e1Bounds[i].width &&
    playerBounds.left + playerBounds.width > e1Bounds[i].left &&
    playerBounds.top < e1Bounds[i].top + e1Bounds[i].height &&
    playerBounds.top + playerBounds.height > e1Bounds[i].top) {
    // Collision detected
    // Handle collision logic here
    if(!cooldown){
    lives-=1;
    timer13=0;
    cooldown=true;
    timery=0;
   
    sound2.play();    
    health.setPosition(0, 0);
    health.setScale(3,3);
    while(timery<0.5){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
     
    
    sound2.play();
    window.display();
    p->sprite.setPosition(340,700);
    } 
  }  
}

for (int i=0;i<numBeta;i++){
    if (playerBounds.left < bombBounds2[i].left + bombBounds2[i].width &&
    playerBounds.left + playerBounds.width > bombBounds2[i].left &&
    playerBounds.top < bombBounds2[i].top + bombBounds2[i].height &&
    playerBounds.top + playerBounds.height > bombBounds2[i].top) {
    // Collision detected
    // Handle collision logic here
    if(!cooldown){
    lives--;
    timer13=0;
    cooldown=true;
    timery=0;
   
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<0.5){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
    
    e2[i].b->bombs.setPosition(1000,1000);
    p->sprite.setPosition(340,700);
    } 
  }
}
for (int i=0;i<numBeta;i++){
    if (playerBounds.left < e2Bounds[i].left + e2Bounds[i].width &&
    playerBounds.left + playerBounds.width > e2Bounds[i].left &&
    playerBounds.top < e2Bounds[i].top + e2Bounds[i].height &&
    playerBounds.top + playerBounds.height > e2Bounds[i].top) {
    // Collision detected
    // Handle collision logic here
    if(!cooldown){
    lives-=1;
    timer13=0;
    cooldown=true;
    timery=0;
   
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<1){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
    
    
    window.display();
    p->sprite.setPosition(340,700);
    } 
  }
}

for (int i=0;i<numGamma;i++){
    if (playerBounds.left < bombBounds3[i].left + bombBounds3[i].width &&
    playerBounds.left + playerBounds.width > bombBounds3[i].left &&
    playerBounds.top < bombBounds3[i].top + bombBounds3[i].height &&
    playerBounds.top + playerBounds.height > bombBounds3[i].top) {
    // Collision detected
    // Handle collision logic here
    if(!cooldown){
    lives-=1;
    timer13=0;
    cooldown=true;
    timery=0;
   
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<1){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
    e3[i].b->bombs.setPosition(1000,1000);
    p->sprite.setPosition(340,700);
    } 
  }  
}
for (int i=0;i<numGamma;i++){
    if (playerBounds.left < e3Bounds[i].left + e3Bounds[i].width &&
    playerBounds.left + playerBounds.width > e3Bounds[i].left &&
    playerBounds.top < e3Bounds[i].top + e3Bounds[i].height &&
    playerBounds.top + playerBounds.height > e3Bounds[i].top) {
    // Collision detected
    // Handle collision logic here
    if(!cooldown){
    lives-=1;
    timer13=0;
    cooldown=true;
    timery=0;
   
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<0.5){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
    window.display();
    p->sprite.setPosition(340,700);
    } 
  }
}

for (int i = 0; i < numAlpha; i++) {
    for (int j = 0; j < p->numBullets ; j++) {
         if (bulletBounds[j].left < e1Bounds[i].left + e1Bounds[i].width &&
        bulletBounds[j].left + bulletBounds[j].width > e1Bounds[i].left &&
        bulletBounds[j].top < e1Bounds[i].top + e1Bounds[i].height &&
        bulletBounds[j].top + bulletBounds[j].height > e1Bounds[i].top) {
            // Collision detected between bullet j and enemy i
            // Remove enemy from the array and decrease the number of enemies
            for (int k = i; k < numAlpha - 1; k++) {
                e1[k] = e1[k + 1];
            }
            
               sound3.play();
            score += (10 *level);
            numAlpha--;
            p->numBullets--;
            // Handle other collision logic if needed
            break; // Exit the loop since collision has been handled for this bullet
        }
    }
}

for (int i = 0; i < numBeta; i++) {
    for (int j = 0; j < p->numBullets ; j++) {
         if (bulletBounds[j].left < e2Bounds[i].left + e2Bounds[i].width &&
        bulletBounds[j].left + bulletBounds[j].width > e2Bounds[i].left &&
        bulletBounds[j].top < e2Bounds[i].top + e2Bounds[i].height &&
        bulletBounds[j].top + bulletBounds[j].height > e2Bounds[i].top) {
            // Collision detected between bullet j and enemy i
            // Remove enemy from the array and decrease the number of enemies
            for (int k = i; k < numBeta - 1; k++) {
                e2[k] = e2[k + 1];
            }
            sound3.play();
            score += (20*level);
            numBeta--;
            p->numBullets--;
            // Handle other collision logic if needed
            break; // Exit the loop since collision has been handled for this bullet
        }
    }
 }    
for (int i = 0; i < numGamma; i++) {
    for (int j = 0; j < p->numBullets ; j++) {
         if (bulletBounds[j].left < e3Bounds[i].left + e3Bounds[i].width &&
        bulletBounds[j].left + bulletBounds[j].width > e3Bounds[i].left &&
        bulletBounds[j].top < e3Bounds[i].top + e3Bounds[i].height &&
        bulletBounds[j].top + bulletBounds[j].height > e3Bounds[i].top) {
            // Collision detected between bullet j and enemy i
            // Remove enemy from the array and decrease the number of enemies
            for (int k = i; k < numGamma - 1; k++) {
                e3[k] = e3[k + 1];
            }
            sound3.play();
            score += (30* level);
            numGamma--;
            p->numBullets--;
            // Handle other collision logic if needed
            break; // Exit the loop since collision has been handled for this bullet
        }
    }
  }
    FloatRect dangerBounds=p1->add->getSprite().getGlobalBounds();
    if (!collisionDetected && playerBounds.left < dangerBounds.left + dangerBounds.width &&
    playerBounds.left + playerBounds.width > dangerBounds.left &&
    playerBounds.top < dangerBounds.top + dangerBounds.height &&
    playerBounds.top + playerBounds.height > dangerBounds.top) {
        if(!cooldown){
        lives-=1;
        timer13=0;
        cooldown=true;
        collisionDetected=true;
       p1->add->getSprite().move(1000,1000);
       timer8=0;
       timery=0;
   
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<0.5){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
    window.display();
    p->sprite.setPosition(340,700);
    }
  }
        FloatRect fireBounds=p2->add->getSprite().getGlobalBounds();
    if (!collisionDetected && time_level>2 && playerBounds.left < fireBounds.left + fireBounds.width &&
    playerBounds.left + playerBounds.width > fireBounds.left &&
    playerBounds.top < fireBounds.top + fireBounds.height &&
    playerBounds.top + playerBounds.height > fireBounds.top) {
        fire=true;
        sound6.play();
        collisionDetected=true;
        timer9=0;
        timer10=0;
      p2->add->getSprite().setPosition(1000, 1000);
    }
    FloatRect fBounds=f.getGlobalBounds();
     for (int i = 0; i < numAlpha; i++) {
    
         if (time_level>2 && fBounds.left < e1Bounds[i].left + e1Bounds[i].width &&
        fBounds.left + fBounds.width > e1Bounds[i].left &&
        fBounds.top < e1Bounds[i].top + e1Bounds[i].height &&
        fBounds.top + fBounds.height > e1Bounds[i].top) {
            // Collision detected between bullet j and enemy i
            // Remove enemy from the array and decrease the number of enemies
            for (int k = i; k < numAlpha - 1; k++) {
                e1[k] = e1[k + 1];
            }
            sound3.play();
            score += (10 *level);
            numAlpha--;
            // Handle other collision logic if needed
            break; // Exit the loop since collision has been handled for this bullet
    }
  } 
    for (int i = 0; i < numGamma; i++) {
    
         if (time_level>2 && fBounds.left < e3Bounds[i].left + e3Bounds[i].width &&
        fBounds.left + fBounds.width > e3Bounds[i].left &&
        fBounds.top < e3Bounds[i].top + e3Bounds[i].height &&
        fBounds.top + fBounds.height > e3Bounds[i].top) {
            // Collision detected between bullet j and enemy i
            // Remove enemy from the array and decrease the number of enemies
            for (int k = i; k < numGamma - 1; k++) {
                e3[k] = e3[k + 1];
            }
            sound3.play();
            score += (10 *level);
            numGamma--;
            // Handle other collision logic if needed
            break; // Exit the loop since collision has been handled for this bullet
    }
  } 
    for (int i = 0; i < numBeta; i++) {
    
         if (time_level>2 && fBounds.left < e2Bounds[i].left + e2Bounds[i].width &&
        fBounds.left + fBounds.width > e2Bounds[i].left &&
        fBounds.top < e2Bounds[i].top + e2Bounds[i].height &&
        fBounds.top + fBounds.height > e2Bounds[i].top) {
            // Collision detected between bullet j and enemy i
            // Remove enemy from the array and decrease the number of enemies
            for (int k = i; k < numBeta - 1; k++) {
                e2[k] = e2[k + 1];
            }
            sound3.play();
            score += (10 *level);
            numBeta--;
            // Handle other collision logic if needed
            break; // Exit the loop since collision has been handled for this bullet
    }
  } 
    
}
 //cout<<numAlpha<<" "<<numBeta<<" "<<numGamma<<endl;
    e4->getBeam().setPosition(0,e4->y+200);
    e4->getSprite().setPosition(0,e4->y);
    if (monster && timer5<5 && time_level>2)
    {
        e4->beam_move("");
    FloatRect Beam=e4->getBeam().getGlobalBounds();
    FloatRect playerBounds = p->sprite.getGlobalBounds();
        if (playerBounds.left < Beam.left + Beam.width &&
    playerBounds.left + playerBounds.width > Beam.left &&
    playerBounds.top < Beam.top + Beam.height &&
    playerBounds.top + playerBounds.height > Beam.top) {
    // Collision detected
    // Handle collision logic here
    if(!cooldown){
    lives--;
    cooldown=true;
    timer13=0;
    timery=0;
   
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<0.5){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
    window.display();
    p->sprite.setPosition(340,700);
    } 
}  

}

    if(monster && time_level>2){
        
	    e4->fire();
        
    FloatRect playerBounds = p->sprite.getGlobalBounds();
    FloatRect MonsterBounds=e4->getSprite().getGlobalBounds();
    
    if (!collisionDetected2 && playerBounds.left < MonsterBounds.left + MonsterBounds.width &&
    playerBounds.left + playerBounds.width > MonsterBounds.left &&
    playerBounds.top < MonsterBounds.top + MonsterBounds.height &&
    playerBounds.top + playerBounds.height > MonsterBounds.top) {
    // Collision detected
    // Handle collision logic here
    if(!cooldown){
    collisionDetected2==true;
    lives--;
    timer13=0;
    cooldown=true;
   timery=0;
   
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<0.5){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
    window.display();
    p->sprite.setPosition(340,700);
        } 
    }   
}     
    if(dragon && time_level>2){
          if ( timer - time_shoot2 >= 0.2 )
	    {shoot_halt2 = false;}
	    
	   if (!shoot_halt2)// && Keyboard::isKeyPressed(Keyboard::Space))
        {
     if(p->sprite.getPosition().x>0 && p->sprite.getPosition().x<260)
        e6->beam_move("l");
     if(p->sprite.getPosition().x>260 && p->sprite.getPosition().x<520)
        e6->beam_move("s");
    if(p->sprite.getPosition().x>520 && p->sprite.getPosition().x<780)
        e6->beam_move("r");
        time_shoot2=timer;
        shoot_halt2=true;

        FloatRect ballBounds[e6->get_numballs()];
        for(int i=0;i<e6->get_numballs();i++)
            ballBounds[i]=e6->f[i].fireball.getGlobalBounds();

        for (int i=0;i<e6->get_numballs();i++){
            if (playerBounds.left < ballBounds[i].left + ballBounds[i].width &&
            playerBounds.left + playerBounds.width > ballBounds[i].left &&
            playerBounds.top < ballBounds[i].top + ballBounds[i].height &&
            playerBounds.top + playerBounds.height > ballBounds[i].top) {
            // Collision detected
            // Handle collision logic here
            
            if(!cooldown){
            lives--;
            timer13=0;
            cooldown==true;
            timery=0;
           // collisionDetected2==true;
    sound2.play();    
    health.setPosition(0, 00);
    health.setScale(3,3);
    while(timery<0.5){
       
	    window.draw(background);  // setting background
         timery +=time;
        window.draw(health);
        
        window.display();
        }
            e6->f[i].fireball.setPosition(1000,1000);
            p->sprite.setPosition(340,730);
           
            } 
        }     
      }  
    } 
     e6->update_fireball();
    }
	/////  Call your functions here            ////
	//////////////////////////////////////////////
    if(time_monster - e4->getDelay()>=10 && time_level>2 && !dragon){
        monster=true;
        
    }
    if(monster){
        timer5 += time;
        timer14 +=time;
    }

    if(timer14>15){
        monster=false;
        timer5=0;
        time_monster=0;
        timer14=0;
        check=true;
        }
    
    if(time_dragon - e6->getDelay()>=20 && time_level>2 && !monster){
        dragon=true; 
    }

    if(dragon)
        timer15 +=time;
    if(timer15>5)
    {
        dragon=false;
        time_dragon=0;
        timer15=0;
        check2=true;;
    }
	
   // if(timer3>40){
	 for (int i = 0; i < p->numBullets; i++)
        {
            window.draw(p->b[i].bullets);
        }

   for (int i = 0; i < numAlpha; i++) {
                 window.draw(e1[i].b->bombs);
            
          }
    for (int i = 0; i < numAlpha; i++) {
            
                window.draw(e1[i].s1);
          }
    for (int i = 0; i < numBeta; i++) {
                window.draw(e2[i].b->bombs);
                window.draw(e2[i].s1);
           }
     for (int i = 0; i < numGamma; i++) {
                window.draw(e3[i].b->bombs);
                window.draw(e3[i].s1);
           }
    for(int i=0;i<lives;i++)
        window.draw(heart[i]);
  if(fire && timer10<5){
    f.setPosition(p->sprite.getPosition().x-54 , p->sprite.getPosition().y-1200);
    window.draw(f);
  }
  else{
    fire==false;
    f.setPosition(1000,1000);
  }
  window.draw(p->add->getSprite());
  window.draw(p->sprite);
  window.draw(p1->add->getSprite());
  window.draw(p2->add->getSprite());
  window.draw(p3->add->getSprite());
  window.draw(p4->add->getSprite());
  window.draw(p5->add->getSprite());
  window.draw(p6->add->getSprite());  
  //window.draw(e6->getSprite());
  if(monster){ 
    window.clear(Color::Black); //clears the screen
	window.draw(background); 
    window.draw(p->add->getSprite());
    window.draw(p->sprite);
    window.draw(p3->add->getSprite());
    window.draw(p4->add->getSprite());
    window.draw(p5->add->getSprite());
    for(int i=0;i<lives;i++)
        window.draw(heart[i]);
  
  }
  if(dragon){ 
    window.clear(Color::Black); //clears the screen
	window.draw(background); 
    window.draw(A->getSprite());
    window.draw(p->sprite);
    window.draw(p3->add->getSprite());
    window.draw(p4->add->getSprite());
    window.draw(p5->add->getSprite());
    for(int i=0;i<lives;i++)
        window.draw(heart[i]);
  
    for(int i=0;i<e6->get_numballs() ;i++)
         window.draw(e6->f[i].fireball);
  }
    string str2 = to_string(lives);
     string str3=  to_string(level);
     
     text.setString("Score:");
         text.setCharacterSize(20);
         text.setFillColor(sf::Color::White);
         text.setStyle(sf::Text::Bold | sf::Text::Underlined);
         text.setPosition(sf::Vector2f(700,00));
         window.draw(text);

         text.setString(str1);
         text.setCharacterSize(20);
         text.setFillColor(sf::Color::Cyan);
         text.setPosition(sf::Vector2f(700,20));
         window.draw(text);

         /*text.setString("lives:");
         text.setCharacterSize(20);
         text.setFillColor(sf::Color::Green);
         text.setStyle(sf::Text::Bold | sf::Text::Underlined);
         text.setPosition(sf::Vector2f(10,0));
         window.draw(text);

         text.setString(str2);
         text.setCharacterSize(20);
         text.setFillColor(sf::Color::Green);
         text.setPosition(sf::Vector2f(10,20));
         window.draw(text);*/

          text.setString("level:");
         text.setCharacterSize(50);
         text.setFillColor(sf::Color::Red);
         text.setStyle(sf::Text::Bold);
         text.setPosition(sf::Vector2f(320,0));
         window.draw(text);

         text.setString(str3);
         text.setCharacterSize(40);
         text.setFillColor(sf::Color::Red);
         text.setPosition(sf::Vector2f(360,55));
         window.draw(text);

    
        if(time_level<2)
        {
         
            window.draw(level1);
        }
       
    if(check)
        score+=40;
    check=false;
    if(check2)
        score+=50;
    check2=false;
    if(monster && timer5<5 && time_level>2)
         window.draw(M.beam);
        
     if(monster && time_level>2)
        window.draw(M.monster);

    if(dragon && time_level>2)
        window.draw(e6->getSprite());
    if(timer5>7 && timer5<8)
        timer5=0;
     
     if(lives==0){
        music.stop();
        gamestart=false;
        gameover.setTexture(tex2);
        gameover.setPosition(-10,0);
        gameover.setScale(0.75,0.65);
        window.draw(gameover);
        if(lives==0)
        {
         cout<<"Enter your name: ";
            cin>>name;
            checkAndReplaceRecord(name, score);
            // sortRecords();
            top10Records = getTop10Records();
            m.scores=top10Records;
            text2.setString(m.scores);
            }
       // window.draw(text2);
         
            if(lives==0 && Keyboard::isKeyPressed(Keyboard::Num1))
            {
                Game g;
                g.start_game();
                return ;
            }
        }
	
	window.display();  //Displying all the sprites
	
   
//	timer=0;
      }
      level=0;
      wave=0;
    }


}


};


void checkAndReplaceRecord(const std::string& playerName, int score) {
    
	std::ifstream inputFile("Scores.txt");
    
	std::ofstream outputFile("temp.txt");
    std::string line;
    bool recordFound = false;

    while (std::getline(inputFile, line)) {
        std::istringstream iss(line);
        std::string name;
        int previousScore;
        iss >> name >> previousScore;

        if (name == playerName) {
            recordFound = true;
            if (score > previousScore) {
                outputFile << playerName << " " << score << std::endl;
            } else {
                outputFile << line << std::endl;
            }
        } else {
            outputFile << line << std::endl;
        }
    }

    if (!recordFound) {
        outputFile << playerName << " " << score << std::endl;
    }

    inputFile.close();
    outputFile.close();

    std::remove("Scores.txt");
    std::rename("temp.txt", "Scores.txt");
    sortRecords();
    
}

// Function to sort records in the file
void sortRecords() {
    const int MAX_RECORDS = 100; // Maximum number of records
	PlayerRecord records[MAX_RECORDS];
    
	int numRecords = 0;

    std::ifstream inputFile("Scores.txt");
    std::string line;

    // Read records into the array
    while (std::getline(inputFile, line)) {
        std::istringstream iss(line);
        iss >> records[numRecords].playerName >> records[numRecords].score;
        numRecords++;
    }
    inputFile.close();

    // Sort the records
    for (int i = 0; i < numRecords - 1; i++) {
        for (int j = 0; j < numRecords - i - 1; j++) {
            if (records[j].score < records[j + 1].score) {
                PlayerRecord temp = records[j];
                records[j] = records[j + 1];
                records[j + 1] = temp;
            }
        }
    }

    // Write the sorted records back to the file
    std::ofstream outputFile("Scores.txt");
    for (int i = 0; i < numRecords; i++) {
        outputFile << records[i].playerName << "\t\t" << records[i].score << std::endl;
    }
    outputFile.close();
}

// Function to retrieve the first 10 records as a string
std::string getTop10Records() {
    std::ifstream inputFile("Scores.txt");
    std::string line;
    std::string top10Records;

    for (int i = 0; i < 10 && std::getline(inputFile, line); ++i) {
        top10Records += line + "\n";
    }

    inputFile.close();

    return top10Records;
}


