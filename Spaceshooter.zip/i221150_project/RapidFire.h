#ifndef RAPIRDFIRE_H
#define RAPIDFIRE_H

#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Addon.h"

using namespace sf;

class Rapid:public Addon
{
public:
    Texture tex;
    Sprite  rapid;
    float delay;
    
    Rapid()
    {
        delay=20 + rand()%100;
        tex.loadFromFile("img/PNG/Power-ups/powerupYellow_bolt.png");
        rapid.setTexture(tex);
        rapid.setPosition(1000,1000);
        rapid.setScale(0.75,0.75);
    }

    void apply() override
    {
      rapid.setPosition(rand()%700,0);
    }

    void move()
    {
        rapid.move(0,0.2);
    }
    Sprite& getSprite() override
    {
       return rapid;
    }
    float getDelay()
    {
        return delay;
    }
};



#endif