#ifndef FIREBALL_H
#define FIREBALL_H
#include <SFML/Graphics.hpp>
#include <string.h>
#include <cmath>

using namespace sf;


class Fireball
{
   public:
 	Texture shoot,shoot2;
 	Sprite fireball;
 	bool straight , rightwards , leftwards ;
 	

 	Fireball(){
        shoot.loadFromFile("img/fireball.png");
        shoot2.loadFromFile("img/laser_up_right.jpeg");
        fireball.setTexture(shoot);
        fireball.setPosition(-1000,-1000);
       
       }
  void fireball_move()
{
  if(straight) {
    fireball.move(0, 0.4);
  }
  else if(rightwards) {
    fireball.move(0.4, 0.4);
  }
  else if(leftwards) {
    fireball.move(-0.4, 0.4);
  }
 }


};
#endif
