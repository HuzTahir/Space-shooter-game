#ifndef DANGER_H
#define DANGER_H

#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Addon.h"

using namespace sf;

class Danger:public Addon
{
    public:
         Texture tex;
         Sprite danger;
        float delay;
    Danger()
    {
        delay=10 + rand()%20;
        tex.loadFromFile("img/PNG/Power-ups/powerupRed_bolt.png");
        danger.setPosition(1000,0);
        danger.setTexture(tex);
    }
    void apply() override
    {
      danger.setPosition(rand()%700,0);
    }

    void move()
    {
        danger.move(0,0.2);
    }
    Sprite& getSprite() override
    {
       return danger;
    }
    float getDelay()
    {
        return delay;
    }
};

#endif