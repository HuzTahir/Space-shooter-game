#ifndef BULLET_H
#define BULLET_H
#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>

using namespace sf;

class bullet
{
 public:
 	Texture shoot,shoot2;
 	Sprite bullets;
 	float speed=1.0;
 	bool straight , rightwards , leftwards,rightup,leftup, rightdown,leftdown ;
 	

 	bullet(){
        shoot.loadFromFile("img/PNG/Lasers/laserGreen01.png");
        shoot2.loadFromFile("img/laser_up_right.jpeg");
        bullets.setTexture(shoot);
        bullets.setPosition(-1000,-1000);
       
       }
  void bullet_move()
{
  if(straight) {
    bullets.move(0, -1);
  }
  else if(rightwards) {
    bullets.move(1, -1);
  }
  else if(leftwards) {
    bullets.move(-1, -1);
  }
  else if(rightup){
    bullets.move(-0.3,-1);
    }
  else if(rightdown){
    bullets.move(-0.5,-1);
    }
  else if(leftup){
    bullets.move(0.3,-1);
    }
  else if(leftdown){
    bullets.move(0.5,-1);
    }
  
 }
};

#endif


/*#ifndef BULLET_H
#define BULLET_H
#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>

using namespace sf;

class bullet
{
 public:
 	Texture shoot;
 	Sprite* bullets[10];
 	int numBullets ; // Number of bullets currently active

 	bullet(){
 	 numBullets = 0; // Number of bullets currently active

 	for (int i = 0; i < 10; i++) 
        bullets[i] = nullptr;
        shoot.loadFromFile("img/laserGreen02.png");
       }
};

#endif*/


