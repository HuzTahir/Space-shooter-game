#ifndef FIRE_H
#define FIRE_H

#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Addon.h"

using namespace sf;

class Fire:public Addon
{
public:
    Texture tex;
    Sprite fire;
    float delay;
    
    Fire()
    {
        delay=rand()%30;
        tex.loadFromFile("img/PNG/Power-ups/bold_silver.png");
        fire.setTexture(tex);
        fire.setPosition(1000,1000);
        fire.setScale(1.3,1.3);
    }

    void apply() override
    {
      fire.setPosition(rand()%700,0);
    }

    void move()
    {
        fire.move(0,0.2);
    }
    Sprite& getSprite() override
    {
       return fire;
    }
    float getDelay()
    {
        return delay;
    }
};



#endif