#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "bullet.h"
#include "Alpha.h"
#include"Enemy.h"
#include"invader.h"
#include "Addon.h"
using namespace sf;

class Player//: public bullet
{
public:
bullet b[20];
int numBullets=0;
Texture tex,tex1,tex2,tex3,tex4,effect;
Sprite sprite;
Sprite* eff[10];
//Sprite* bullets[10]; // Array of pointers to bullet sprites
Addon* add;
float speed=0.01;
int x,y;
bool firing = false; // Flag to indicate if player is firing
bool rapidfire=false;
Player()
{
    
}
Player(std::string png_path)
{


tex.loadFromFile(png_path);
tex2.loadFromFile("img/r.png");
tex3.loadFromFile("img/rb.png");
tex1.loadFromFile("img/l.png");
tex4.loadFromFile("img/lb.png");
sprite.setTexture(tex);
x=340;y=700;
sprite.setPosition(x,y);
sprite.setScale(0.5,0.5);
}
  void fire(char s) {
    numBullets++; // Increment the number of active bullets
    b[numBullets-1].bullets.setPosition(sprite.getPosition().x+20 , sprite.getPosition().y); // Set the bullet's position to the center of the player sprite
    b[numBullets-1].bullets.setScale(0.75, 0.75); // Set the bullet's scale
 
   if (s == 'x' || s == 'n')
{
   
    b[numBullets - 1].rightwards = true;
    b[numBullets - 1].leftwards = false;
    b[numBullets - 1].straight = false;
}
else if (s == 'y' || s == 'z')
{
   
    b[numBullets - 1].rightwards = false;
    b[numBullets - 1].leftwards = true;
    b[numBullets - 1].straight = false;
}

else 
{
    
    b[numBullets - 1].rightwards = false;
    b[numBullets - 1].leftwards = false;
    b[numBullets - 1].straight = true;
}



    if (numBullets >= 20) return; // Maximum number of bullets reached
   

}


void move(std::string s){
    float delta_x=0, delta_y=0;
    speed=0.1;
  sprite.setTexture(tex);
    if(s == "l")
        delta_x = -1;
    else if(s == "r")
        delta_x = 1;
    if(s == "u")
        delta_y = -1;
    else if(s == "d")
        delta_y = 1;
    if(s == "x"){
        delta_x = 1;
        delta_y = -1;
        
    }
    if(s == "y"){
        delta_x =-1;
        delta_y = -1;
    }
    if(s == "z"){
        delta_x = 1;
        delta_y = 1;
    }
     if(s == "n"){
        delta_x = -1;
        delta_y = 1;
        
    }
   
      if (delta_x != 0 || delta_y != 0) { // check if two keys are pressed together
        if (delta_x > 0 && delta_y < 0) { // up and right
             speed=0.01;
            sprite.setTexture(tex2); // change sprite's texture to the rotated picture for this direction
             
        }
        else if (delta_x > 0 && delta_y > 0) { // down and right
            speed=0.01;
            sprite.setTexture(tex1); // change sprite's texture to the rotated picture for this direction
           
        }
        else if (delta_x < 0 && delta_y > 0) { // down and left
             speed=0.01;
            sprite.setTexture(tex2); // change sprite's texture to the rotated picture for this direction
        }
        else if (delta_x < 0 && delta_y < 0) { // up and left
         speed=0.01;
            sprite.setTexture(tex1); // change sprite's texture to the rotated picture for this direction
      
        }  
           
    }
    delta_x *= speed;
    delta_y *= speed;

    if(sprite.getPosition().x < 0)
        sprite.setPosition(650, sprite.getPosition().y);
    else if(sprite.getPosition().x > 780)
        sprite.setPosition(0, sprite.getPosition().y);
    if(sprite.getPosition().y < 0)
        sprite.setPosition(sprite.getPosition().x, 700);
    else if(sprite.getPosition().y > 780)
        sprite.setPosition(sprite.getPosition().x, 0);

    sprite.move(delta_x, delta_y);

    
}

void update_bullet()
{
   for (int i = 0; i < numBullets ; i++) {
    b[i].bullet_move(); // Update the position of the bullet
      if (b[i].bullets.getPosition().y < 0) {
        for (int j = i; j < numBullets -1 ; j++) {
            b[j] = b[j+1]; // Shift the remaining bullets in the array
        }
        numBullets--; // Decrement the number of active bullets
        i--; // Move back one index to check the bullet that was shifted into this position
      } 
   }
}

void rapid_fire()
{
    if (rapidfire)
    {
        numBullets = 7; // Set the number of active bullets to 7

        // Set the positions and directions for each bullet
        b[0].bullets.setPosition(sprite.getPosition().x + 20, sprite.getPosition().y);
        b[0].rightwards = false;
        b[0].leftwards = true;
        b[0].straight = false;
        b[0].rightup=false;
        b[0].leftup=false;
        b[0].rightdown=false;
        b[0].leftdown=false;
     //   b[0].bullets.move(-0.3, -0.3);

        b[1].bullets.setPosition(sprite.getPosition().x + 20, sprite.getPosition().y);
        b[1].rightwards = false;
        b[1].leftwards = false;
        b[1].straight = true;
        b[1].rightup=false;
        b[1].leftup=false;
        b[1].rightdown=false;
        b[1].leftdown=false;
     //   b[1].bullets.move(-0.2, -0.2);
        b[2].bullets.setPosition(sprite.getPosition().x + 20, sprite.getPosition().y);
        b[2].rightwards = false;
        b[2].leftwards = false;
        b[2].straight = false;
        b[2].rightup=true;
        b[2].leftup=false;
        b[2].rightdown=false;
        b[2].leftdown=false;

        b[3].bullets.setPosition(sprite.getPosition().x + 20, sprite.getPosition().y);
        b[3].rightwards = false;
        b[3].leftwards = false;
        b[3].straight = false;
        b[3].rightup=false;
        b[3].leftup=true;
        b[3].rightdown=false;
        b[3].leftdown=false;
        
        b[4].bullets.setPosition(sprite.getPosition().x + 20, sprite.getPosition().y);
        b[4].rightwards = false;
        b[4].leftwards = false;
        b[4].straight = false;
        b[4].rightup=false;
        b[4].leftup=false;
        b[4].rightdown=true;
        b[4].leftdown=false;

        b[5].bullets.setPosition(sprite.getPosition().x + 20, sprite.getPosition().y);
        b[5].rightwards = false;
        b[5].leftwards = false;
        b[5].straight = false;
        b[5].rightup=false;
        b[5].leftup=false;
        b[5].rightdown=false;
        b[5].leftdown=true;
        // Continue setting positions and directions for the rest of the bullets

        b[6].bullets.setPosition(sprite.getPosition().x + 20, sprite.getPosition().y);
        b[6].rightwards = true;
        b[6].leftwards = false;
        b[6].straight = false;
        b[6].rightup=false;
        b[6].leftup=false;
        b[6].rightdown=false;
        b[6].leftdown=false;
       // b[6].bullets.move(0.3, -0.3);
    }
}

void useAddon()
{
    add->apply();
}

};
