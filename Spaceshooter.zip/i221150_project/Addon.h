#ifndef ADDON_H
#define ADDON_H

#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>

using namespace sf;

class Addon {
public:
    virtual void apply() = 0;
    virtual Sprite& getSprite()=0;
    virtual float getDelay()=0;
    virtual void move()=0;
};

#endif