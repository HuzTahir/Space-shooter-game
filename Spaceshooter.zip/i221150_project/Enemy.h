#ifndef ENEMY_H
#define ENEMY_H
#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "bomb.h"
#include "Fireball.h"

using namespace sf;


class Enemy {
public:
    bomb* b=nullptr;
    Fireball f[20];
    float delay;
    int x=300 , y=100 ;
    bool leftwards,rightwards,straight;
    int numEnemies = 0; // Number of enemies currently active
    Sprite s;
   
    Enemy() {
        numEnemies = 0;
        
        leftwards=false;
        rightwards=false;
        straight=false;
    }

    virtual void fire() {}
    
    virtual void beam_move(std::string s) {}
    virtual int get_numballs()  { return -1; }
    virtual Sprite getBeam() {return s; }
    virtual void update_fireball() {}
    virtual Sprite getSprite() const = 0;
    virtual float getDelay() const = 0;
    };
#endif


//FloatRect <var> = s1.getGlobalBounds();
//<var>.width