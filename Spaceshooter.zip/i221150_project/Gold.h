#ifndef GOLD_H
#define GOLD_H

#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Addon.h"

using namespace sf;

class Gold:public Addon
{
public:
    Texture tex;
    Sprite gold;
    float delay;
    
    Gold()
    {
        delay=10 + rand()%100;
        tex.loadFromFile("img/gold.png");
        gold.setTexture(tex);
        gold.setPosition(1000,1000);
        gold.setScale(0.05,0.05);
    }

    void apply() override
    {
      gold.setPosition(rand()%700,0);
    }

    void move()
    {
        gold.move(0,0.2);
    }
    Sprite& getSprite() override
    {
       return gold;
    }
    float getDelay()
    {
        return delay;
    }
};



#endif