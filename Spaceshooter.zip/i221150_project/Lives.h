#ifndef LIVES_H
#define LIVES_H

#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Addon.h"

using namespace sf;

class Lives:public Addon
{
public:
    Texture tex;
    Sprite lives;
    float delay;
    
    Lives()
    {
        delay=10 + rand()%40;
        tex.loadFromFile("img/PNG/Power-ups/pill_red.png");
        lives.setTexture(tex);
        lives.setPosition(1000,1000);
        lives.setScale(1.3,1.3);
    }

    void apply() override
    {
      lives.setPosition(rand()%700,0);
    }

    void move()
    {
        lives.move(0,0.2);
    }
    Sprite& getSprite() override
    {
       return lives;
    }
    float getDelay()
    {
        return delay;
    }
};



#endif