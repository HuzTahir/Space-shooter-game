#ifndef BOMB_H
#define BOMB_H
#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>

using namespace sf;

class bomb
{
 public:
 	Texture shoot;
 	Sprite bombs;
 	int numBomb=1 ; // Number of bullets currently active

 	bomb(){
 	 	 numBomb = 1; // Number of bullets currently active
		 for(int i=0;i<5;i++){
		if(i>4)
		break;
		 }
		 shoot.loadFromFile("img/enemy_laser.png");
         bombs.setTexture(shoot);
       }
	bomb(std::string png_path){
 	 	 numBomb = 1; // Number of bullets currently active
         shoot.loadFromFile(png_path);
         bombs.setTexture(shoot);
       }
       
       void bomb_move()
       {	
       		 bombs.move(0,0.3);
	   }

	   Sprite& getbomb()
	   {
			return bombs;
	   }
};

#endif
