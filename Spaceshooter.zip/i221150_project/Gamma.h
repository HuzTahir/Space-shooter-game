#ifndef GAMMA_H
#define GAMMA_H
#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Enemy.h"
#include "invader.h"
#include "bomb.h"


using namespace sf;



class Gamma: public invader
{
 public:
	
	Texture image;
	Sprite s1;
	
	Gamma()
	{
		delay=2;
		image.loadFromFile("img/PNG/Enemies/enemyGreen4.png");
		s1.setTexture(image);
		s1.setPosition(x-200,y);	
		s1.setScale(0.7,0.7);
		b=new bomb();
		b->bombs.setPosition(s1.getPosition().x + 24, s1.getPosition().y + 6);
		b->bombs.setScale(0.75,0.75);
		
	}
	
	Gamma(float initialX, float initialY)
	{
		delay=2;
		image.loadFromFile("img/PNG/Enemies/enemyGreen4.png");
		s1.setTexture(image);
		 //  x = rand() % 500; // Random x position between 0 and 499
    	 //  y = rand() % 300; // Random y position between 0 and 299
    
   		 s1.setPosition(initialX, initialY);
   		 s1.setScale(0.75, 0.75);
		b=new bomb("img/PNG/Lasers/laserRed09.png");
		b->bombs.setPosition(s1.getPosition().x + 24, s1.getPosition().y + 6);
		b->bombs.setScale(0.75,0.75);
		
	}
	void fire()
	{
	
    		b->bombs.setPosition(s1.getPosition().x+24 , s1.getPosition().y+6);
				//	b->bomb_move();

	}
	 Sprite getSprite() const override {
        return s1;
    }

    float getDelay() const override {
        return delay;
    }
};

#endif
