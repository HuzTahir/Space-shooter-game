#ifndef MENU_H
#define MENU_H
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <string>
//#include "game.h"
#include <iostream>
class Menu{
public:
bool flag=false;
bool gamestart=false;
bool m=false,h=false,i1=false,i2=false,ex=false;
std :: string scores;
Texture tex,tex1,tex2,tex3,tex4,tex5;
Sprite menu,instructions,score;
//add menu attributes here
Menu()
{
	tex.loadFromFile("img/menu.png");
	tex1.loadFromFile("img/Highscores.png");
	tex2.loadFromFile("img/instruction.png");
	tex3.loadFromFile("img/exit.png");
	tex4.loadFromFile("img/instructions.png");
	tex5.loadFromFile("img/background_19.png");
	menu.setTexture(tex);

//constructors body
}

void display_menu()

{
//	
   // Game g; 
	
//display menu screen here
	RenderWindow window(VideoMode(780, 780),"Master piece");
    Clock clock;
    float timer=0;
    int count =0;
	int count2=0;
	const int MAX_COUNT = 3;
	bool isKeyDown = false; // Flag to track key press
sf::Clock switchTimer; // Timer to track the elapsed time
const sf::Time SWITCH_DELAY = sf::seconds(0.1f); // Delay between texture switches
	sf::Music music;
	 sf::Font font;	
	sf::Font font2;
    if (!font2.loadFromFile("img/Roboto-Black.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
       
    }
	sf:: Text text;
	text.setFont(font2);
    sf::Text text2;
    text2.setFont(font2);
    text2.setCharacterSize(25);
    text2.setFillColor(sf::Color::White);
    text2.setPosition(300.f, 235.f);
   	if(!music.openFromFile("img/SkyFire.ogg"))
   {}
    music.setLoop(true);
    music.play(); 

    while (window.isOpen())
    {
		
    	

    	window.draw(menu);
    
    	 
    	Event e;
        while (window.pollEvent(e))
        {  
            if (e.type == Event::Closed) // If cross/close is clicked/pressed
                window.close(); //close the game                        	    
        }
       
		
	/*if (count==0 && Keyboard::isKeyPressed(Keyboard::Enter)){
		gamestart=true;
		if(gamestart){
				music.stop();
			    window.close();
                g.start_game();
				
                }
            }   
 	else if (count ==0 && Keyboard::isKeyPressed(Keyboard::Down)){
 		count=1;
 	/*	obj2.loadFromFile("img/Highscores.png");
 		score.setTexture(obj1);
 		flag=true;
		while(flag){
				window.draw(score);
				window.display();
				if (count ==1 && Keyboard::isKeyPressed(Keyboard::Down)){
					flag=false;
					count=2;
					
			}
 		}
 	}
 	
 		obj1.loadFromFile("img/instruction.png");
		instructions.setTexture(obj1);
		flag=true;
		while(!Keyboard::isKeyPressed(Keyboard::Down)){
				window.draw(instructions);
				window.display();
		// std::cin.get();
		if (count ==1 && Keyboard::isKeyPressed(Keyboard::Enter)){
		obj1.loadFromFile("img/instructions.png");
		instructions.setTexture(obj1);
		flag=true;
		while(flag){
				window.draw(instructions);
				window.display();
				if (count==1 && Keyboard::isKeyPressed(Keyboard::Num7)){
					flag=false;
					window.clear(Color::Black);
					window.draw(menu);
					window.display();
					count=0;
				

					}
				
			}	
		}
		else if (count ==1 && Keyboard::isKeyPressed(Keyboard::Down)){
		count=2;
		obj2.loadFromFile("img/exit.png");
		score.setTexture(obj2);
		flag=true;
		while(flag){
				window.draw(score);
				window.display();
				if (count ==2 && Keyboard::isKeyPressed(Keyboard::Enter))
    				exit(0);
		}		
    	 } 
   		else if (count ==1 && Keyboard::isKeyPressed(Keyboard::Up)){
    		count=0;
    		while(count==0){
    		window.draw(menu);
    		window.display();
    			if (count ==0 && Keyboard::isKeyPressed(Keyboard::Enter)){
		gamestart=true;
		if(gamestart){
				music.stop();
                window.close();
                g.start_game();
                }
            }   
 	else if (count ==0 && Keyboard::isKeyPressed(Keyboard::Down)){
 		count=1;
 	/*	obj2.loadFromFile("img/Highscores.png");
 		score.setTexture(obj1);
 		flag=true;
		while(flag){
				window.draw(score);
				window.display();
				if (count ==1 && Keyboard::isKeyPressed(Keyboard::Down)){
					flag=false;
					count=2;
					
			}
 		}
 	}
 	
 		obj1.loadFromFile("img/instruction.png");
		instructions.setTexture(obj1);
		flag=true;
		while(!Keyboard::isKeyPressed(Keyboard::Down)){
				window.draw(instructions);
				window.display();
		// std::cin.get();
		if (count ==1 && Keyboard::isKeyPressed(Keyboard::Enter)){
		obj1.loadFromFile("img/instructions.png");
		instructions.setTexture(obj1);
		flag=true;
		while(flag){
				window.draw(instructions);
				window.display();
				if (count==1 && Keyboard::isKeyPressed(Keyboard::Num7)){
					flag=false;
					window.clear(Color::Black);
					window.draw(menu);
					window.display();
					count=0;
				

					}
				
			}	
		}
		else if (count ==1 && Keyboard::isKeyPressed(Keyboard::Down)){
		count=2;
		obj2.loadFromFile("img/exit.png");
		score.setTexture(obj2);
		flag=true;
		while(flag){
				window.draw(score);
				window.display();
				if (count ==2 && Keyboard::isKeyPressed(Keyboard::Enter))
    				exit(0);
		}		
    	 } 
   		else if (count ==1 && Keyboard::isKeyPressed(Keyboard::Up)){
    		count=0;
    		while(count==0){
    		window.draw(menu);
    		window.display();	
    		}
    	  }
    	  	
  	  
		
	      }
             }	
    	   }
         } 	
       }
     }*/
   	 
// add functionality of all the menu options here

//if Start game option is chosen 
    

/*switch (count)
{
    case 0:
        if (Keyboard::isKeyPressed(Keyboard::Enter))
        {
            if (menu.getTexture() == &tex)
            {
                // Code to handle Enter press on tex
                // For example, start the game or perform an action
            }
            else if (menu.getTexture() == &tex1)
            {
                count = 3;
                menu.setTexture(tex3);
            }
        }
        else if (!Keyboard::isKeyPressed(Keyboard::Enter) && Keyboard::isKeyPressed(Keyboard::Down))
        {
            count = 1;
            menu.setTexture(tex1);
        }
        break;

    case 1:
        if (Keyboard::isKeyPressed(Keyboard::Enter))
        {
            if (menu.getTexture() == &tex1)
            {
                gamestart = false;
                h = true;
                menu.setTexture(tex4);
            }
            else if (menu.getTexture() == &tex2)
            {
                // Code to handle Enter press on tex2
                // For example, perform an action specific to tex2
            }
        }
        else if (h == true && Keyboard::isKeyPressed(Keyboard::Num7))
        {
            count = 0;
            menu.setTexture(tex);
        }
        else if (count == 1 && Keyboard::isKeyPressed(Keyboard::Up))
        {
            count = 0;
            menu.setTexture(tex);
        }
        else if (count == 1 && Keyboard::isKeyPressed(Keyboard::Down))
        {
            count = 2;
            menu.setTexture(tex2);
        }
        break;

    case 2:
        if (Keyboard::isKeyPressed(Keyboard::Up))
        {
            count = 1;
            menu.setTexture(tex1);
        }
        else if (count == 2 && Keyboard::isKeyPressed(Keyboard::Down))
        {
            count = 3;
            menu.setTexture(tex3);
        }
        break;

    case 3:
        if (Keyboard::isKeyPressed(Keyboard::Up))
        {
            count = 2;
            menu.setTexture(tex2);
        }
        break;
}*/


	


if (switchTimer.getElapsedTime() >= SWITCH_DELAY) {
    if (Keyboard::isKeyPressed(Keyboard::Down)) {
        if (!isKeyDown) {
            isKeyDown = true;
            count = (count + 1) % (MAX_COUNT + 1); // Increment count and wrap around
            switchTimer.restart(); // Restart the switch timer
        }
    } else if (Keyboard::isKeyPressed(Keyboard::Up)) {
        if (!isKeyDown) {
            isKeyDown = true;
            count = (count - 1 + MAX_COUNT + 1) % (MAX_COUNT + 1); // Decrement count and wrap around
            switchTimer.restart(); // Restart the switch timer
        }
    } else {
        isKeyDown = false; // Reset the flag when no key is pressed
    }
}

// Set the texture based on the count
if (count == 0) {
    menu.setTexture(tex);
} else if (count == 1) {
    menu.setTexture(tex1);
		if(count==1 && Keyboard::isKeyPressed(Keyboard::Enter)){
			h==true;
			gamestart=false;
			menu.setTexture(tex5);
			text2.setString(scores);
			window.draw(text2);
			text.setString("High Scores:");
         	text.setCharacterSize(30);
         	text.setFillColor(sf::Color::White);
         	text.setStyle(sf::Text::Bold | sf::Text::Underlined);
         	text.setPosition(sf::Vector2f(300,150));
        	 window.draw(text);
		}
		else if(h==true && Keyboard::isKeyPressed(Keyboard::Num7))
		{
			 h=false;
			 menu.setTexture(tex1);
			
		}
		
} else if (count == 2) {
    menu.setTexture(tex2);
	if(count==2 && Keyboard::isKeyPressed(Keyboard::Enter)){
			h==true;
			gamestart=false;
			menu.setTexture(tex4);
			
			
		}
		else if(h==true && Keyboard::isKeyPressed(Keyboard::Num7))
		{
			 h=false;
			 menu.setTexture(tex1);
		}
}
	else if (count == 3) {
    menu.setTexture(tex3);
		if(count==3 && Keyboard::isKeyPressed(Keyboard::Enter))
			exit(0);
}


if (count==0 && Keyboard::isKeyPressed(Keyboard::Enter)) {
    gamestart = true;
    music.stop();
    window.close();
  //  g.start_game();
	//scores=g.top10Records;
}


		window.display();
   }
 }

};
#endif