#ifndef Dragon_H
#define Dragon_H
#include <SFML/Graphics.hpp>
#include <string.h>
#include <cmath>
#include "Enemy.h"
#include "Fireball.h"

using namespace sf;

class Dragon: public Enemy
{
    public:
    Texture tex,tex2;
    Sprite dragon,beam;
    float delay;
   
    int numBalls=0;

    Dragon ()
    {
        delay= rand()%25;
        tex.loadFromFile("img/dragon1.png");
        dragon.setTexture(tex);
        dragon.setPosition(x - 65,y);
        dragon.setScale(1,1);
     //   tex2.loadFromFile("img/fireball.jpeg");
        beam.setTexture(tex2);
        beam.setPosition(dragon.getPosition().x+20 , dragon.getPosition().y);
    }

    Sprite getBeam()
    {
        return f->fireball;
    }
    Sprite getSprite() const override
    {
        return dragon;
    }

    void beam_move(std::string s) {
    numBalls++; // Increment the number of active bullets
    
    f[numBalls-1].fireball.setPosition(dragon.getPosition().x+100 , dragon.getPosition().y+200) ; // Set the bullet's position to the center of the player sprite
    f[numBalls-1].fireball.setScale(0.3, 0.3); // Set the bullet's scale
 
   if (s == "r")
    {
   
    f[numBalls - 1].rightwards = true;
    f[numBalls - 1].leftwards = false;
    f[numBalls - 1].straight = false;
    }
    else if (s == "l")
    {   
   
    f[numBalls - 1].rightwards = false;
    f[numBalls - 1].leftwards = true;
    f[numBalls - 1].straight = false;
    }

    else if(s == "s")
    {
    
    f[numBalls - 1].rightwards = false;
    f[numBalls - 1].leftwards = false;
    f[numBalls - 1].straight = true;
    }   



    if (numBalls >= 20) return; // Maximum number of bullets reached
   

    }

    float getDelay() const override
    {
        return delay;
    }

    void update_fireball()
  {   
   for (int i = 0; i < numBalls ; i++) {
    f[i].fireball_move(); // Update the position of the bullet
      if (f[i].fireball.getPosition().y > 700) {
        for (int j = i; j < numBalls -1 ; j++) {
            f[j] = f[j+1]; // Shift the remaining bullets in the array
        }
        numBalls--; // Decrement the number of active bullets
        i--; // Move back one index to check the bullet that was shifted into this position
      } 
   }
}
    int get_numballs()
    {
        return numBalls;
    }
};

#endif