#ifndef BRONZE_H
#define BRONZE_H

#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Addon.h"

using namespace sf;

class Bronze:public Addon
{
public:
    Texture tex;
    Sprite bronze;
    float delay;
    
    Bronze()
    {
        delay=10 + rand()%25;
        tex.loadFromFile("img/bronze coin.png");
        bronze.setTexture(tex);
        bronze.setPosition(1000,1000);
        bronze.setScale(0.2,0.2);
    }

    void apply() override
    {
      bronze.setPosition(rand()%700,0);
    }

    void move()
    {
        bronze.move(0,0.2);
    }
    Sprite& getSprite() override
    {
       return bronze;
    }
    float getDelay()
    {
        return delay;
    }
};



#endif