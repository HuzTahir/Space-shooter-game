#ifndef Monster_H
#define Monster_H
#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Enemy.h"

class Monster: public Enemy
{
    public:
    Texture tex,tex2;
    Sprite monster,beam;
    float x=0.1;
    float delay=0;

    Monster()
    {
        delay=10 + rand()%45;
        tex.loadFromFile("img/monster1.png");
        tex2.loadFromFile("img/monsterbeam.png");
        monster.setTexture(tex); 
        beam.setTexture(tex2);
        monster.setPosition(0,y);
        monster.setScale(0.5,0.5);
        beam.setPosition(0,y+200);
        beam.setScale(0.5,1.3);
    }

    void fire()
{
    float delta_x = 0;
    static bool movingRight = true; // Flag to track movement direction

    if (movingRight) {
        delta_x = 0.1;
        monster.move(delta_x, 0);

        if (monster.getPosition().x >= 500) {
            movingRight = false; // Change direction when reaching right end
        }
    } else {
        delta_x = -0.1;
        monster.move(delta_x, 0);

        if (monster.getPosition().x < 0) {
            movingRight = true; // Change direction when reaching left end
        }
    }

   // beam_move();
}

    void beam_move(std::string s)
    {
       beam.setPosition(monster.getPosition().x +75 , monster.getPosition().y + 100);
    }
     
     Sprite getBeam() {
        return beam;
     }
Sprite getSprite() const override {
        return monster;
    }

    float getDelay() const override {
        return delay;
    }
    
};

#endif
