#ifndef SILVER_H
#define SILVER_H

#include <SFML/Graphics.hpp>
#include<string.h>
#include <cmath>
#include "Addon.h"

using namespace sf;

class Silver:public Addon
{
public:
    Texture tex;
    Sprite silver;
    float delay;
    
    Silver()
    {
        delay=10 + rand()%50;
        tex.loadFromFile("img/silver.png");
        silver.setTexture(tex);
        silver.setPosition(1000,1000);
        silver.setScale(0.2,0.2);
    }

    void apply() override
    {
      silver.setPosition(rand()%700,0);
    }

    void move()
    {
        silver.move(0,0.2);
    }
    Sprite& getSprite() override
    {
       return silver;
    }
    float getDelay()
    {
        return delay;
    }
};



#endif