#include "game.h"
int main()
{
    
    
    Game G;
    G.start_game(); 
    return 0;
}


